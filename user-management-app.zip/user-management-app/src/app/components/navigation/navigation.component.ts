import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-navigation',
  standalone: true,
  imports: [RouterModule],
  template: `
    <nav>
      <a routerLink="/" routerLinkActive="active">User List</a> |
      <a routerLink="/create" routerLinkActive="active">Create User</a>
    </nav>
  `,
})
export class NavigationComponent {}
