import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { User, UserService } from '../../user.service';

@Component({
  selector: 'app-user-form',
  standalone: true,
  providers:[UserService],
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './user-form.component.html',
})
export class UserFormComponent implements OnInit {
  userForm: FormGroup;
  userId: number | null = null;
  successMessage:string='';
  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService

  ) {
    this.userForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });

    this.successMessage="";
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.userId = +id;
        this.userService.getUserById(this.userId).subscribe((user: User) => {
          this.userForm.patchValue(user);
        });
      }
    });
  }

  onSubmit(): void {
    // If the form is invalid, stop processing and return early
    if (this.userForm.invalid) return;

    // Extract the form data
    const formData = this.userForm.value;

    // Check if userId exists. If it does, it's an update operation; if not, it's a create operation.
    const saveRequest$ = this.userId
      ? this.userService.updateUser(this.userId, formData)  // If updating
      : this.userService.createUser(formData);              // If creating a new user

    // Subscribe to the observable to handle the response
    saveRequest$.subscribe({
      next: (response: any) => {
        // Handle successful response
        this.successMessage = this.userId ? 'User saved successfully!' :'User Created Succesfully';
         console.log('User saved successfully:', response);
        // Add any navigation or state update logic (e.g., redirecting after saving)
      },
      error: (error: any) => {
        // Handle error (e.g., show error message to the user)
        console.error('Error saving user:', error);
      }
    });
  }

}
