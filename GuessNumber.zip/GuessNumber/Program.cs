﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Welcome to the Guessing Game (Digits 1-6 Only)");
        Console.WriteLine("Try to guess the 4-digit secret code.");
        Console.WriteLine("You have  only 10 attempts to guess");

        int[] secretCode = GenerateSecretCode();
        int maxAttempts = 10;

        for (int attempt = 1; attempt <= maxAttempts; attempt++)
        {
            Console.Write($"Attempt {attempt}: ");
            string? input = Console.ReadLine();

            if (!IsValidGuess(input))
            {
                Console.WriteLine("Invalid input. Enter exactly 4 digits from 1 to 6.");
                attempt--;
                continue;
            }

            int[] guess = Array.ConvertAll(input!.ToCharArray(), c => c - '0');

            if (IsCorrectGuess(secretCode, guess))
            {
                Console.WriteLine("Correct! You win!");
                return;
            }

            string hint = GenerateHint(secretCode, guess);
            Console.WriteLine($"Hint: {hint}" );
        }

        Console.WriteLine("\nMax attepts Exceeded. Try again" );
        Console.Write($"The correct guess was: {string.Join("", secretCode)}");
    }

    static int[] GenerateSecretCode()
    {
        Random random = new();
        int[] code = new int[4];
        for (int i = 0; i < 4; i++)
        {
            code[i] = random.Next(1, 7); // 1 to 6
        }
        
        return code;
    }

    static bool IsValidGuess(string? guess)
    {
        return guess is not null &&
               guess.Length == 4 &&
               guess.All(c => c >= '1' && c <= '6');
    }

    static bool IsCorrectGuess(int[] secret, int[] guess)
    {
        return secret.SequenceEqual(guess);
    }

    static string GenerateHint(int[] secret, int[] guess)
    {
        bool[] secretUsed = new bool[4];
        bool[] guessUsed = new bool[4];
        string pluses = "", minuses = "";

        // First pass: correct digit & position
        for (int i = 0; i < 4; i++)
        {
            if (guess[i] == secret[i])
            {
                pluses += "+";
                secretUsed[i] = true;
                guessUsed[i] = true;
            }
        }

        // Second pass: correct digit, wrong position
        for (int i = 0; i < 4; i++)
        {
            if (guessUsed[i]) continue;

            for (int j = 0; j < 4; j++)
            {
                if (!secretUsed[j] && guess[i] == secret[j])
                {
                    minuses += "-";
                    secretUsed[j] = true;
                    break;
                }
            }
        }

        return pluses + minuses;
    }
}
